import { Box, Flex, Text, HStack } from "@chakra-ui/react";
import { FiChevronDown } from "react-icons/fi";
import { Swiper, SwiperSlide } from "swiper/react";
import { FreeMode, Mousewheel } from "swiper/modules";
import "swiper/css";
import "swiper/css/free-mode";

import Reveal from "./Reveal";
import Tag from "./Tag";
import MapLinks from "./MapLinks";

function grad(g) {
  return `linear-gradient(135deg, ${g[0]}, ${g[1]})`;
}

function OptionCard({ opt }) {
  return (
    <Box h="100%" bg="rgba(251,247,242,0.9)" border="1px solid" borderColor="#ece1d3" rounded="14px" p={3.5}>
      <Text fontWeight="900" fontSize="15px" color="#0B2A3D">
        {opt.name}
        {opt.badge && <Tag label={opt.badge[0]} kind={opt.badge[1]} />}
      </Text>
      <Text fontSize="12.5px" color="#4B6B7E" mt={1}>
        {opt.desc}
      </Text>
      <MapLinks links={opt.links} />
    </Box>
  );
}

function Leg({ label }) {
  return (
    <HStack justify="center" gap={2} color="#8aa0ae" fontSize="12.5px" fontWeight="600" my={2.5}>
      <FiChevronDown size={15} />
      <Text>{label}</Text>
    </HStack>
  );
}

export default function StopCard({ stop }) {
  const { time, title, tags, meta, note, links, options, gradient, legAfter } = stop;

  return (
    <>
      <Reveal>
        <Box
          position="relative"
          bg="rgba(255,255,255,0.8)"
          backdropFilter="blur(16px)"
          border="1px solid rgba(255,255,255,0.9)"
          rounded="card"
          boxShadow="0 20px 50px -22px rgba(12,74,110,0.4)"
          p={4.5}
          overflow="hidden"
        >
          <Box position="absolute" left="0" top="0" bottom="0" w="5px" style={{ background: grad(gradient) }} />

          <HStack gap={3} mb={2.5} align="center">
            <Box
              flex="none"
              color="white"
              fontFamily="num"
              fontWeight="800"
              fontSize="13.5px"
              px={3.5}
              py={2}
              rounded="12px"
              whiteSpace="nowrap"
              style={{ background: grad(gradient) }}
              boxShadow="0 8px 18px -8px rgba(12,74,110,0.5)"
            >
              {time}
            </Box>
            <Text fontWeight="900" fontSize="20px" color="brand.900">
              {title}
              {tags && tags.map((t, i) => <Tag key={i} label={t[0]} kind={t[1]} />)}
            </Text>
          </HStack>

          {meta &&
            meta.map(([k, v], i) => (
              <Text key={i} fontSize="13.5px" color="#4B6B7E" my={0.5}>
                <Box as="b" color="#0B2A3D" fontWeight="700" mr={2}>
                  {k}
                </Box>
                {v}
              </Text>
            ))}

          {note && (
            <Box fontSize="13px" color="#9a3b30" bg="rgba(253,241,238,0.9)" rounded="10px" px={3} py={2} mt={2}>
              {note}
            </Box>
          )}

          {links && <MapLinks links={links} />}

          {options && (
            <Box mt={3}>
              <Swiper
                modules={[FreeMode, Mousewheel]}
                freeMode
                mousewheel={{ forceToAxis: true }}
                grabCursor
                spaceBetween={12}
                slidesPerView={1.06}
                breakpoints={{ 640: { slidesPerView: 2.1 }, 1024: { slidesPerView: 2.3 } }}
                style={{ overflow: "visible", paddingBottom: 4 }}
              >
                {options.map((opt, i) => (
                  <SwiperSlide key={i} style={{ height: "auto" }}>
                    <OptionCard opt={opt} />
                  </SwiperSlide>
                ))}
              </Swiper>
            </Box>
          )}
        </Box>
      </Reveal>

      {legAfter && <Leg label={legAfter} />}
    </>
  );
}
